package myPackage;

import java.util.Date;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.wink.common.model.rss.RssChannel;
import org.apache.wink.common.model.rss.RssFeed;
import org.apache.wink.common.model.rss.RssItem;

@Path("/getRss")
public class ProduceRss {
    @GET
    @Produces(MediaType.APPLICATION_XML)
    public RssFeed getRssFeed() {
        RssFeed rss = new RssFeed();

        RssChannel channel = new RssChannel();
        channel.setTitle("Liftoff News");
        channel.setLink("http://liftoff.msfc.nasa.gov");
        channel.setDescription("Liftoff to Space Exploration.");
        channel.setPubDate(new Date().toString());

        RssItem item = new RssItem();
        item.setTitle("Star City");
        item.setLink("http://liftoff.msfc.nasa.gov/news/2003/news-starcity.asp");
        item.setDescription("How do Americans get ready to work with Russians aboard the International Space Station?");

        channel.getItems().add(item);
        rss.setChannel(channel);
        return rss;
    }
}
