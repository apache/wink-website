package myPackage;

import java.io.File;
import java.net.URI;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.apache.wink.common.annotations.Workspace;
import org.apache.wink.common.model.atom.AtomContent;
import org.apache.wink.common.model.atom.AtomEntry;
import org.apache.wink.common.model.atom.AtomFeed;
import org.apache.wink.common.model.atom.AtomLink;
import org.apache.wink.common.model.atom.AtomText;

@Workspace(workspaceTitle = "IISc MILE Lab Weblog", collectionTitle = "Photos")
@Path("/photos")
public class PhotosCollection {
    private static Map<String, File> photos = new HashMap<String, File>();
    private static int               _id    = 0;

    @GET
    @Produces(MediaType.APPLICATION_ATOM_XML)
    public AtomFeed getFeed(@Context UriInfo uriInfo) {
        AtomFeed feed = new AtomFeed();
        feed.setId(uriInfo.getAbsolutePath().toString());
        feed.setTitle(new AtomText("Photos"));
        feed.setUpdated(new Date());
        feed.setBase(uriInfo.getAbsolutePath().toString());
        for (String key : photos.keySet()) {
            URI location = uriInfo.getAbsolutePathBuilder().segment(key).build();
            AtomEntry entry = createEntry(key, location.toString(), "");
            feed.getEntries().add(entry);
        }
        return feed;
    }

    @POST
    @Consumes("image/*")
    @Produces(MediaType.APPLICATION_ATOM_XML)
    public Response postEntry(File inputImage,
                              @Context UriInfo uriInfo,
                              @HeaderParam("Slug") String slug) {
        if (inputImage == null || !inputImage.canRead()) {
            throw new WebApplicationException(Response.Status.BAD_REQUEST);
        }
        String id = (slug == null || slug.length() <= 0) ? "Photo_" + getNewId() : slug;
        photos.put(id, inputImage);
        URI location = uriInfo.getAbsolutePathBuilder().segment(id).build();
        AtomEntry entry = createEntry(id, location.toString(), "");
        return Response.created(location).entity(entry).build();
    }

    @GET
    @Path("{id}")
    @Produces("image/*")
    public Response getEntry(@PathParam("id") String photoId) {
        File image = photos.get(photoId);
        if (image == null) {
            throw new WebApplicationException(Response.Status.NOT_FOUND);
        } else {
            // String mimeType = new
            // MimetypesFileTypeMap().getContentType(image);
            return Response.ok(image, "image/jpeg").build();
        }
    }

    @PUT
    @Path("{id}")
    @Consumes("image/*")
    @Produces(MediaType.APPLICATION_ATOM_XML)
    public AtomEntry putEntry(@PathParam("id") String photoId,
                              File newImage,
                              @Context UriInfo uriInfo) {
        if (newImage == null || !newImage.canRead()) {
            throw new WebApplicationException(Response.Status.BAD_REQUEST);
        }
        photos.put(photoId, newImage);
        URI location = uriInfo.getAbsolutePathBuilder().segment(photoId).build();
        AtomEntry entry = createEntry(photoId, location.toString(), "");
        return entry;
    }

    @DELETE
    @Path("{id}")
    public void deleteEntry(@PathParam("id") String photoId) {
        if (photos.containsKey(photoId)) {
            photos.remove(photoId);
        } else {
            throw new WebApplicationException(Response.Status.NOT_FOUND);
        }
    }

    private static String getNewId() {
        return String.valueOf(++_id);
    }

    private static AtomEntry createEntry(String id, String imgSrc, String imgType) {
        AtomEntry entry = new AtomEntry();
        entry.setId(id);
        entry.setTitle(new AtomText(id));
        entry.setUpdated(new Date());
        AtomContent content = new AtomContent();
        content.setSrc(imgSrc);
        content.setType(imgType);
        entry.setContent(content);
        AtomLink link = new AtomLink();
        link.setHref(imgSrc);
        entry.getLinks().add(link);
        return entry;
    }
}
